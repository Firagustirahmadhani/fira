from django import forms
from .models import Mahasiswa

# ✅ Menggunakan ModelForm supaya bisa dipakai untuk tambah & edit data
class MahasiswaForm(forms.ModelForm):
    class Meta:
        model = Mahasiswa
        fields = ['nama', 'npm', 'email', 'no_hp', 'jurusan', 'alamat']
        widgets = {
            'nama': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Masukkan nama mahasiswa'
            }),
            'npm': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Masukkan NPM'
            }),
            'email': forms.EmailInput(attrs={
                'class': 'form-control',
                'placeholder': 'Masukkan email mahasiswa'
            }),
            'no_hp': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Masukkan nomor HP mahasiswa'
            }),
            'jurusan': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Masukkan jurusan mahasiswa'
            }),
            'alamat': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 2,
                'placeholder': 'Masukkan alamat lengkap'
            }),
        }
        labels = {
            'nama': 'Nama Lengkap',
            'npm': 'NPM',
            'email': 'Email',
            'no_hp': 'Nomor HP',
            'jurusan': 'Jurusan',
            'alamat': 'Alamat',
        }