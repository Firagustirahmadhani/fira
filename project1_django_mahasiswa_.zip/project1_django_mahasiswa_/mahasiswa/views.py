from django.shortcuts import render, redirect, get_object_or_404
from .forms import MahasiswaForm
from .models import Mahasiswa
from django.contrib.auth.decorators import login_required

@login_required(login_url='/admin/login/')
def input_mahasiswa(request):
    pesan = ""
    if request.method == 'POST':
        form = MahasiswaForm(request.POST)
        if form.is_valid():
            form.save()
            pesan = "Data mahasiswa berhasil disimpan."
            form = MahasiswaForm()
    else:
        form = MahasiswaForm()

    semua_mahasiswa = Mahasiswa.objects.all().order_by('id')
    return render(request, 'mahasiswa/input.html', {
        'form': form,
        'pesan': pesan,
        'semua_mahasiswa': semua_mahasiswa,
        'edit_mode': False,
    })

@login_required(login_url='/admin/login/')
def hapus_mahasiswa(request, id):
    mhs = get_object_or_404(Mahasiswa, id=id)
    mhs.delete()
    return redirect('input_mahasiswa')

@login_required(login_url='/admin/login/')
def edit_mahasiswa(request, id):
    mhs = get_object_or_404(Mahasiswa, id=id)

    if request.method == 'POST':
        form = MahasiswaForm(request.POST, instance=mhs)
        if form.is_valid():
            form.save()
            return redirect('input_mahasiswa')
    else:
        form = MahasiswaForm(instance=mhs)

    semua_mahasiswa = Mahasiswa.objects.all().order_by('id')
    return render(request, 'mahasiswa/input.html', {
        'form': form,
        'semua_mahasiswa': semua_mahasiswa,
        'edit_mode': True,
        'mahasiswa_id': id,
    })