from django.db import models

class Mahasiswa(models.Model):
    nama = models.CharField(max_length=100)
    npm = models.CharField(max_length=20)
    email = models.EmailField()
    no_hp = models.CharField(max_length=15, null=True, blank=True)
    jurusan = models.CharField(max_length=100, blank=True)  # <-- tambah field ini
    alamat = models.TextField(blank=True)  # <-- tambah field ini

    def __str__(self):
        return self.nama